package src.com.csc205.projects.bonus.project2;

public enum Iteration {
	
	FORWARD, REVERSE

}